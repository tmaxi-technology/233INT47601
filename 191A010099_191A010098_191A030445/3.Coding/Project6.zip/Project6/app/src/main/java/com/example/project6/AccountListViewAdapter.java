package com.example.project6;

import android.accounts.Account;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class AccountListViewAdapter extends BaseAdapter {
    final ArrayList<TaiKhoan> listTKMD;
    AccountListViewAdapter(ArrayList<TaiKhoan> listTKMD){
        this.listTKMD=listTKMD;
    }
    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View viewAccount;
        if(view ==null){
            viewAccount =View.inflate(viewGroup.getContext(),R.layout.taikhoan_view,null);
        }else viewAccount =view;
        TaiKhoan acc =(TaiKhoan) getItem(i);
        ((TextView) viewAccount.findViewById(R.id.email)).setText(String.format("Email = %s",acc.taikhoan));
        ((TextView) viewAccount.findViewById(R.id.password)).setText(String.format("Password = %s",acc.matkhau));
        return viewAccount;
    }
}
