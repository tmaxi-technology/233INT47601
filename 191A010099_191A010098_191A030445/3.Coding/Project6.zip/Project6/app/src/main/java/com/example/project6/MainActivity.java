package com.example.project6;

import static java.util.Objects.deepEquals;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Dùng Arraylist để chứa tài khoản và mật khẩu mặc định
        ArrayList<TaiKhoan> listTKMD =new ArrayList<TaiKhoan>();
        listTKMD.add(new TaiKhoan("nguyen@gmail.com","1234567890"));
        listTKMD.add(new TaiKhoan("trung@gmail.com","0987654321"));
        listTKMD.add(new TaiKhoan("ngo@gmail.com","123567890"));
        //Ánh xạ
        Button dangnhap=(Button)findViewById(R.id.button);
        Button quenmatkhau=(Button)findViewById(R.id.button2);
        Button dangky=(Button)findViewById(R.id.button3);
        Button gioithieu=(Button)findViewById(R.id.button4);
        Button huongdan=(Button)findViewById(R.id.button5);
        Button xemthem=(Button)findViewById(R.id.button6);
        EditText pEmail=(EditText)findViewById(R.id.editTextText);
        EditText pPassword=(EditText)findViewById(R.id.editTextText2);


        //gói chuyển activity
        final Intent goi =new Intent(this,MainActivity2.class);
        final Intent goidk =new Intent(this,ActivityRegister.class);

        dangnhap.setOnClickListener(new View.OnClickListener()
        {


            @Override
            public void onClick(View view)
            {
                //Khai báo biến để lúc ấn đăng nhập ,set edittext tai khoản mật khẩu cho biến a
                TaiKhoan a = new TaiKhoan(pEmail.getText().toString(),pPassword.getText().toString());
                //kiểm tra có nhập thiếu 1 trong 2 ,mật khẩu và email hay không
                if(pEmail.getText().length() !=0 && pPassword.getText().length() !=0)
                {
                    //kiểm tra email và mật khẩu có tồn tại hay không?

                    if (a.checkAllAccount(listTKMD,a))
                    {
                        Toast.makeText(MainActivity.this,"Bạn đã đăng nhập thành công!",Toast.LENGTH_SHORT).show();
                        //thỏa hết điều kiện ,chuyển sang main 2
                        startActivity(goi);
                    } else
                    {
                        //Nếu nhập thông tin nhưng không trùng khớp
                        Toast.makeText(MainActivity.this,"Bạn nhập sai thông tin đăng nhập!",Toast.LENGTH_SHORT).show();
                    }
                }else
                {
                    //Nếu không nhập 1 trong 2 ,tài khoản và mật khẩu
                    Toast.makeText(MainActivity.this,"Bạn nhập thiếu email hoặc mật khẩu!",Toast.LENGTH_SHORT).show();
                }
            }
        });
        dangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(goidk);
            }
        });

    }
}