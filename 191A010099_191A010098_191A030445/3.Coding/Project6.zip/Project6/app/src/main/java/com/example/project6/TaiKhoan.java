package com.example.project6;

import android.database.Cursor;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TaiKhoan {
    public String taikhoan;
    public String matkhau;
    public  ArrayList  DanhSachh;
    public TaiKhoan(String x, String y)
    {
        this.taikhoan = x;
        this.matkhau = y;
    }
    public void LoadArraylist(ArrayList DanhSach){
        DanhSachh=DanhSach;
    }
    //phương thức lấy thông tin
    public String getTaikhoan()
    {
        return this.taikhoan;
    }

    public String getMatKhau()
    {
        return this.matkhau;
    }
    //phương thức set thông tin
    public void settaikhoan(String taikhoan)
    {
        this.taikhoan = taikhoan;
    }

    public void setMatkhau(String matkhau)
    {
        this.taikhoan = matkhau;
    }
    //override lại equals để có thể so sánh 2 đối tượng
    @Override
    //phương thức này trả về true false
    public boolean equals(Object obj)
    {
        //nếu đối tượng muốn so sánh = 0 hoặc class đối tượng muốn so sánh khác ,return về false
        if (obj == null || getClass() != obj.getClass()) return false;
        //ép obj kiểu Object sang kiểu class
        TaiKhoan anotherPerson = (TaiKhoan) obj;
        //lấy các phần tử trong obj đem so sánh với this, if true return true
        return taikhoan.equals(anotherPerson.taikhoan) && matkhau == anotherPerson.matkhau;
    }
    //phương thức này trả về true false khi so sánh 2 đối tượng
    public boolean checkOneAccount(TaiKhoan aArray,TaiKhoan a)
    {
        //biến này dùng để lưu kết quả so sánh
    boolean ketqua = false;
    //so sánh 2 đối tượng class ,nếu giống nhau thì return về true;
            if(aArray.getTaikhoan().equals(this.getTaikhoan()) && aArray.getMatKhau().equals(this.getMatKhau()))
                ketqua = true;
        return ketqua;
    }
    //phương thức này dùng để check giống nhau giữa 1 class và list class
    public boolean checkAllAccount(ArrayList<TaiKhoan> AllAccount,TaiKhoan a)
    {
        boolean ketqua = false;
        for(int i=0;i<3;i++)
        {
            if(a.checkOneAccount(AllAccount.get(i),a) )
                ketqua = true;
        }
        return ketqua;
    }


}
